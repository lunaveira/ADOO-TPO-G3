package Test;

import Clients.*;
import Strategies.BajarPesoStrategy;
import Strategies.MantenerFiguraStrategy;
import Strategies.TonificarStrategy;

public class Main {

    public static void main(String[] args) {

        Objetivo objetivo1 = new Objetivo();
    //    objetivo1.setTipoEstrategia(TipoEstrategia.TONIFICAR);

        Socio socio = new Socio(TipoEstrategia.BAJAR);

        System.out.println("objetivo: " + socio.getTipoEstrategia());


        TonificarStrategy tonificar = new TonificarStrategy();
        BajarPesoStrategy bajarPeso = new BajarPesoStrategy();
        MantenerFiguraStrategy mantenerFigura = new MantenerFiguraStrategy();
        switch (socio.getTipoEstrategia()){
            case BAJAR: objetivo1.setStrategy(bajarPeso);
            case TONIFICAR: objetivo1.setStrategy(tonificar);
            case MANTENER: objetivo1.setStrategy(mantenerFigura);
        }


        socio.ingresar("Lucia Naveira","Lucia123");

        socio.setObjetivo(objetivo1);
        objetivo1.setSocio(socio);


        Rutina rutina = new Rutina();
        rutina.crearRutina();


        socio.cambiarObjetivo();

        Entrenamiento entrenamiento = new Entrenamiento();
        rutina.agregarEntrenamiento(entrenamiento);
        //rutina.quitarEntrenamiento(entrenamiento);

        Medicion medicion = new Medicion();
        socio.registrarMedicion();

        objetivo1.objCumplido();

        /*
        Ejercicio ejercicio1 = new Ejercicio();
        ejercicio1.setNombreEjercicio("Sentadilla");
        ejercicio1.setRepeticiones(10);
        ejercicio1.setSeries(10);
        ejercicio1.setPesoAsignado(100);
        entrenamiento.agregarEjercicio(ejercicio1);
        rutina.reforzarRutina();

         */

        socio.ObtenerPremio();

    }

}
