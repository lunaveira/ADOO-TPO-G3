package Adapters;

import Clients.Medicion;

/**
 * 
 */
public class AdapterMedicionConcreto implements IAdapterMedicion {

    private String API;

    /**
     * @return
     * este metodo estaba privado y lo cambie aca y en el diagrama
     */
    public Medicion registrarMedicion() { //para despues corre el main como hacemos aca, le hardcodeamos los valores?
        Medicion medicion = new Medicion();
        return medicion;
    }

    /**
     * @return
     * este metodo no entiendo que deberia hacer y si tiene que calcular el peso ideal no deberia ser en esta clase
     */
    public Double getPesoIdeal() {
        return Math.random(); //aca devolver un random
    }

    public Double getMasaIdeal(){ //como le paso este peso ideal
        return Math.random(); //aca devolver un random
    }

    public Double getGrasaIdeal(){ //como le paso este peso ideal
        return Math.random(); //aca devolver un random
    }

}