package Adapters;

import java.util.*;

/**
 * 
 */
public interface IAdapterLogin {

    void ingresar(String user, String password);

}