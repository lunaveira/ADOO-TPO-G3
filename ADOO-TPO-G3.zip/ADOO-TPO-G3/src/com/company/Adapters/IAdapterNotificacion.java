package Adapters;

import Clients.Notificacion;

public interface IAdapterNotificacion {

    public void notificar(Notificacion notificacion);
}
