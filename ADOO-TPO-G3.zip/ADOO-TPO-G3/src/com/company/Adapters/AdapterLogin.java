package Adapters;

import java.util.*;

/**
 * 
 */
public class AdapterLogin implements IAdapterLogin{

    /**
     * @param user 
     * @param password 
     * @return
     */
    public void ingresar(String user, String password) {
        System.out.println("Usuario "+ user +" ingresado correctamente");
    }

}