package Adapters;

import Clients.Medicion;

/**
 * 
 */
public interface IAdapterMedicion {

    /**
     * @return
     */
    Medicion registrarMedicion();

    Double getPesoIdeal();

    Double getMasaIdeal();

    Double getGrasaIdeal();

}