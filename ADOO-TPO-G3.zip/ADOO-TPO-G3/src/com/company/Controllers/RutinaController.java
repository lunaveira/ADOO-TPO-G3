package Controllers;

import Clients.Rutina;

/**
 * 
 */
public class RutinaController {

    /**
     * Default constructor
     */
    public RutinaController() {
    }

    /**
     * Class Attributes
     */
    private Rutina rutina;

    /**
     * @param rutina
     * @return
     */
    public void agregarRutina(Rutina rutina) {
        Rutina rutina1 = new Rutina();
    }

}