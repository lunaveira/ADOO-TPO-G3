package Controllers;

;

import Clients.Objetivo;

/**
 * NOSE SI ESTAN BIEN LOS METODOS DE AGREGAR, QUITA, MODIFICAR EN LOS CONTROLLERS
 */
public class ObjetivoController {

    /**
     * Default constructor
     */
    public ObjetivoController() {
    }

    /**
     * Class Attributes
     */
    private Objetivo objetivo;

    /**
     * @param obj 
     * @return
     */
    public void agregarObjetivo(Objetivo obj) {
        Objetivo objetivo = new Objetivo();
    }

}