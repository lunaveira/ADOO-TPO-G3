package Controllers;

import java.util.ArrayList;

import Clients.Ejercicio;


/**
 * 
 */
public class EjercicioController {

    /**
     * Default constructor
     */
    public EjercicioController() {
    }

    /**
     * Class Attributes
     */
    private Ejercicio ejercicio; //para mi el controllador tiene todos los ejercicios que hay, en cambio entrenamiento tiene un par de ellos


    /**
     * @param ej 
     * @return
     */
    public void agregarEjercicio(Ejercicio ej) {
        ejercicio.agregarEjercicio(ej);
    }

}