package Controllers;

import Clients.Socio;

/**
 * 
 */
public class SocioController {

    /**
     * Default constructor
     */
    public SocioController() {
    }

    /**
     * Class Attributes
     */
    private Socio socio;



    public void ingresar(String user, String password) {
        socio.ingresar(user, password);
    }

    /**
     * @return
     */
    public void registrarMedicion() {
        socio.registrarMedicion();
    }

}