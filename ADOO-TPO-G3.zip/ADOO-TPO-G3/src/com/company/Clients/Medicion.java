package Clients;

import java.util.*;

/**
 * 
 */
public class Medicion {

    /**
     * Default constructor
     */
    public Medicion() {
    }


    private Date fecha;
    private double peso;
    private double grasa;
    private double masa;

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getGrasa() {
        return grasa;
    }

    public void setGrasa(double grasa) {
        this.grasa = grasa;
    }

    public double getMasa() {
        return masa;
    }

    public void setMasa(double masa) {
        this.masa = masa;
    }
}