package Clients;

/**
 * 
 */
public class Dedicacion extends TrofeoObservador {

    /**
     * Default constructor
     */
    public Dedicacion() {
    }

    /**
     * 
     */
    private Objetivo objetivo;


    @Override
    public void chequearPremio() {
        if(objetivo.objCumplido()){
            Notificacion notificacion = new Notificacion("Ganaste un trofeo a la dedicacion");
        }
    }
}