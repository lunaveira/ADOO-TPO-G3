package Clients;

public enum TipoEstrategia {
    TONIFICAR,
    MANTENER,
    BAJAR
}
