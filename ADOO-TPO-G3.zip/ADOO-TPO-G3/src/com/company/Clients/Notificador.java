package Clients;

import Adapters.IAdapterNotificacion;


public class Notificador {

    private Notificacion notificacion;
    private IAdapterNotificacion adapterNotificacion;



    public void notificar() {
      adapterNotificacion.notificar(notificacion);
    }

}