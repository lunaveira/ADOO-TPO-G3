package Clients;

/**
 * 
 */
public class Constancia extends TrofeoObservador {


    public Constancia() {
    }

    /**
     * 
     */
    private Rutina rutina;

    @Override
    public void chequearPremio() {
        if(rutina.rutinaCumplida()){
            Notificacion notificacion = new Notificacion("Ganaste un trofeo a la constancia");
        }
    }
}