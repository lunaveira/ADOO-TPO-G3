package Clients;

/**
 * 
 */
public class EjercicioReforzado extends Ejercicio {

    /**
     * Default constructor
     */
    public EjercicioReforzado() {
    }

    /**
     * Class Attributes
     */
    private Ejercicio ejercicio;
    private Double refuerzo = 1.1;

    public Ejercicio getEjercicio() {
        return ejercicio;
    }

    public void setEjercicio(Ejercicio ejercicio) {
        this.ejercicio = ejercicio;
    }

    @Override
    public void reforzarEjercicio() {
        ejercicio.setSeries((int) (ejercicio.getSeries() * refuerzo));
        ejercicio.setRepeticiones((int) (ejercicio.getRepeticiones() * refuerzo));
        ejercicio.setPesoAsignado((int) (ejercicio.getPesoAsignado() * refuerzo));
        System.out.println(this.ejercicio.getRepeticiones());
        System.out.println(this.ejercicio.getSeries());
        System.out.println(this.ejercicio.getPesoAsignado());
    }

}