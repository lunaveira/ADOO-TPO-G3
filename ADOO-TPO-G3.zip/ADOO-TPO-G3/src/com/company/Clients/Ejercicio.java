package Clients;

import Controllers.EjercicioController;

import java.util.ArrayList;

/**
 * 
 */
public class Ejercicio {

    /**
     * Default constructor
     */
    public Ejercicio() {
    }

    /**
     * Class Attributes
     */
    private int series;
    private int repeticiones;
    private int pesoAsignado;
    private int nivelAerobico;
    private String exigenciaMuscular;
    private GrupoMuscular grupoMuscular;
    private String nombreEjercicio;

    private EjercicioRealizado ejercicioRealizado;

    public int getSeries() {
        return series;
    }

    public void setSeries(int series) {
        this.series = series;
    }

    public void setRepeticiones(int repeticiones) {
        this.repeticiones = repeticiones;
    }

    public int getRepeticiones() {
        return repeticiones;
    }

    public int getPesoAsignado() {
        return pesoAsignado;
    }

    public void setPesoAsignado(int pesoAsignado) {
        this.pesoAsignado = pesoAsignado;
    }

    public int getNivelAerobico() {
        return nivelAerobico;
    }

    public void setNivelAerobico(int nivelAerobico) {
        this.nivelAerobico = nivelAerobico;
    }

    public String getExigenciaMuscular() {
        return exigenciaMuscular;
    }

    public void setExigenciaMuscular(String exigenciaMuscular) {
        this.exigenciaMuscular = exigenciaMuscular;
    }

    public GrupoMuscular getGrupoMuscular() {
        return grupoMuscular;
    }

    public String getNombreEjercicio() {
        return nombreEjercicio;
    }

    public void setNombreEjercicio(String nombreEjercicio) {
        this.nombreEjercicio = nombreEjercicio;
    }

    public void reforzarEjercicio() {
    }

    public void agregarEjercicio(Ejercicio ej) {
        Archivo archivo = new Archivo("ejercicios.txt");
        ArrayList lista = archivo.listar();
        lista.add(ej);
        archivo.guardar(lista);
    }


}