package Clients;

public class Notificacion {

    public Notificacion(String mensaje) {
        this.mensaje = getMensaje();

    }

    private String mensaje;


    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }


}