package Clients;

/**
 * 
 */
public abstract class TrofeoObservador {

    /**
     * Default constructor
     */
    public TrofeoObservador() {
    }

    /**
     * Class Attributes
     */
    private Notificador notificador;
    private TipoTrofeo tipoTrofeo;

    public Notificador getNotificador() {
        return notificador;
    }

    public void setNotificador(Notificador notificador) {
        this.notificador = notificador;
    }

    public TipoTrofeo getTipoTrofeo() {
        return tipoTrofeo;
    }

    public void setTipoTrofeo(TipoTrofeo tipoTrofeo) {
        this.tipoTrofeo = tipoTrofeo;
    }

    /**
     * @return
     */
    public abstract void chequearPremio();



}