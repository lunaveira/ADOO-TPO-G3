package Clients;

public enum TipoSexo {
    MASCULINO,
    FEMENINO
}
