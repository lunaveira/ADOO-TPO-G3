package Clients;

/**
 * 
 */
public class EjercicioRealizado {

    /**
     * Default constructor
     */
    public EjercicioRealizado() {
    }

    /**
     * Class Attributes
     */
    private Ejercicio ejercicio;
    private Entrenamiento entrenamiento;
    private int seriesRealizadas;
    private int repsRealizadas;

    public int getSeriesRealizadas() {
        return seriesRealizadas;
    }

    public void setSeriesRealizadas(int seriesRealizadas) {
        this.seriesRealizadas = seriesRealizadas;
    }

    public int getRepsRealizadas() {
        return repsRealizadas;
    }

    public void setRepsRealizadas(int repsRealizadas) {
        this.repsRealizadas = repsRealizadas;
    }

    public boolean checkearEjercicioRealizado(){
        if(ejercicio.getRepeticiones() == this.repsRealizadas && ejercicio.getSeries() == this.seriesRealizadas){
            return true;
        }
        return false;
    }
}