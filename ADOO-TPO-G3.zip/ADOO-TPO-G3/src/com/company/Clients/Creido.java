package Clients;

import Clients.Medicion;

import java.util.ArrayList;

/**
 * 
 */
public class Creido extends TrofeoObservador {

    /**
     * Default constructor
     */
    public Creido() {
    }

    /**
     * 
     */
    private Socio socio;

    @Override
    public void chequearPremio() {
        int contador = 0;
        ArrayList<Medicion> mediciones = (ArrayList<Medicion>) socio.getMediciones();
        for (Medicion med: mediciones){
            contador++;
        }
        if (contador > 3){
            Notificacion notificacion = new Notificacion("Ganaste un trofeo al mas creido");
        }
    }
}