package Clients;

import java.util.*;

import Strategies.ObjetivoStrategy;

/**
 * 
 */
public class Objetivo {

    /**
     * Default constructor
     */
    public Objetivo() {
    }

    /**
     * Class Attributes
     */
    private TipoEstrategia tipoEstrategia;
    private ObjetivoStrategy strategy;
    private Rutina rutina;
    private ArrayList<TrofeoObservador> trofeos;
    private Socio socio;

    public TipoEstrategia getTipoEstrategia() {
        return tipoEstrategia;
    }

    public void setTipoEstrategia(TipoEstrategia tipoEstrategia) {
        this.tipoEstrategia = tipoEstrategia;
    }

    public void setTrofeos(ArrayList<TrofeoObservador> trofeos) {
        this.trofeos = trofeos;
    }

    public Socio getSocio() {
        return socio;
    }

    public void setSocio(Socio socio) {
        this.socio = socio;
    }

    public ObjetivoStrategy getStrategy() {
        return strategy;
    }

    public void setStrategy(ObjetivoStrategy strategy) {
        this.strategy = strategy;
    }

    public Rutina getRutina() {
        return rutina;
    }

    public void setRutina(Rutina rutina) {
        this.rutina = rutina;
    }

    public ArrayList<TrofeoObservador> getTrofeos() {
        return trofeos;
    }


    public boolean objCumplido() {
        return strategy.objCumplido(socio);
    }

    public void ObtenerPremio() {
        for (TrofeoObservador premios: trofeos) {
            premios.chequearPremio();
        }
    }

}