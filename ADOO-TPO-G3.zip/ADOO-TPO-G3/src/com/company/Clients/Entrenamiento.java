package Clients;

import java.util.*;

/**
 * 
 */
public class Entrenamiento {

    /**
     * Default constructor
     */
    public Entrenamiento() {
    }

    /**
     * Class Attributes
     */
    private ArrayList<Ejercicio> ejercicios;
    private ArrayList<EjercicioRealizado> ejerciciosRealizados;
    private String nombre;

    public ArrayList<Ejercicio> getEjercicios() {
        return ejercicios;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Private Methods
     */
    private Ejercicio buscarEjercicio(Ejercicio ejercicio ){
        for (Ejercicio ej: ejercicios){
            if (ejercicio == ej ){
                return ej;
            }

        }
        return null;
    }

    /**
     * @param ej
     * @return
     */

    public void agregarEjercicio(Ejercicio ej) {
        //ej.
    }


    public void quitarEjercicio(Ejercicio ej) { //aca lo cambie y puse que me pasen el nombre del ej como parametre
        Ejercicio ejercicio = new Ejercicio();
        ejercicio = this.buscarEjercicio(ej);
        if (ejercicio == ej){
            ejercicios.remove(ejercicio);
        }

        System.out.println("ejercicio" + nombre + "eliminado");
    }

    public void reforzarEntrenamiento() {
        for (Ejercicio ejercicio: ejercicios) {
            ejercicio.reforzarEjercicio();
        }
        System.out.println("entrenamiento reforzado");

    }

    public boolean entrenamientoCumplido() {
        for (EjercicioRealizado ej: this.ejerciciosRealizados){
            if(ej.checkearEjercicioRealizado()){
                return true;
            }
        }
        return false;
    }
}