package Clients;

import java.util.ArrayList;

/**
 * 
 */
public class Rutina {

    /**
     * Default constructor
     */
    public Rutina() {
    }

    /**
     * Class Attributes
     */
    private int diasTraining;
    private Objetivo objetivo;
    private int duracion;
    private ArrayList<Entrenamiento> entrenamientos; //agregue los entrenamientos en rutina
    private ArrayList<TrofeoObservador> trofeos;


    /**
     * Private Methods
     */
    private Entrenamiento buscarEntrenamiento(Entrenamiento entrenamiento){
        for (Entrenamiento en: entrenamientos){
            if (en == entrenamiento ){
                return en;
            }

        }
        return null;
    }

    /**
     * @param
     * @return
     */
    public void reforzarRutina() { //este tampoco se bien como hacer
       for (Entrenamiento entrenamiento: entrenamientos) {
           entrenamiento.reforzarEntrenamiento();
       }
       System.out.println("rutina reforzada");

    }

    /**
     * @return
     */
    public boolean rutinaCumplida() {
        for(Entrenamiento en: entrenamientos){
            if (en.entrenamientoCumplido()){
                return true;
            }
        }
        return false;
    }

    public void agregarEntrenamiento(Entrenamiento entrenamiento){
        System.out.println("Entrenamiento agregado");
        //entrenamientos.add(entrenamiento);
    }


    public void quitarEntrenamiento(Entrenamiento en) { //aca lo cambie y puse que me pasen el nombre del ej como parametre
        Entrenamiento entrenamiento = this.buscarEntrenamiento(en);
        if (entrenamiento == en){
            //entrenamientos.remove(entrenamiento);
        }

        System.out.println("ejercicio" + en + "eliminado");
    }

    public void ObtenerPremio() {
        for (TrofeoObservador premios: trofeos) {
            premios.chequearPremio();
        }
    }

    public void crearRutina(){
        System.out.println("rutina creada");
    }


}