package Clients;

import java.util.*;

/**
 * 
 */
public class Firebase {

    /**
     * Default constructor
     */
    public Firebase() {
    }

}