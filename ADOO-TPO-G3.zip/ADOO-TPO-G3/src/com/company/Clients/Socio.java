package Clients;

import java.util.*;

import Adapters.AdapterLogin;
import Adapters.AdapterMedicionConcreto;
import Adapters.IAdapterLogin;
import Adapters.IAdapterMedicion;

/**
 * 
 */
public class Socio {

    private Notificador notificador;
    private ArrayList<Medicion> mediciones;
    private int edad;
    private TipoSexo sexo;
    private Objetivo objetivo;
    private double altura;
    private Rutina rutina;
    private AdapterLogin adapterLogin;
    private ArrayList<TrofeoObservador> trofeos;
    private AdapterMedicionConcreto adapterMedicion;
    private TipoEstrategia tipoEstrategia;

    /**
     * Default constructor
     */
    public Socio(TipoEstrategia tipoEstrategia) {
        super();
        this.tipoEstrategia = tipoEstrategia;
        AdapterLogin adapterLogin1 = new AdapterLogin();
        this.adapterLogin = adapterLogin1;
        AdapterMedicionConcreto adapterMedicionConcreto = new AdapterMedicionConcreto();
        this.adapterMedicion = adapterMedicionConcreto;

    }

    /**
     * Class Attributes
     */


    public ArrayList<Medicion> getMediciones() {
        return mediciones;
    }

    public void setMediciones(ArrayList<Medicion> mediciones) {
        this.mediciones = mediciones;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public TipoSexo getSexo() {
        return sexo;
    }

    public void setSexo(TipoSexo sexo) {
        this.sexo = sexo;
    }

    public Objetivo getObjetivo() {
        return objetivo;
    }

    public void setObjetivo(Objetivo objetivo) {
        this.objetivo = objetivo;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public Rutina getRutina() {
        return rutina;
    }

    public void setRutina(Rutina rutina) {
        this.rutina = rutina;
    }

    public ArrayList<TrofeoObservador> getTrofeos() {
        return trofeos;
    }

    public void setTrofeos(ArrayList<TrofeoObservador> trofeos) {
        this.trofeos = trofeos;
    }

    public AdapterMedicionConcreto getAdapterMedicion() {
        return adapterMedicion;
    }

    public void setAdapterMedicion(AdapterMedicionConcreto adapterMedicion) {
        this.adapterMedicion = adapterMedicion;
    }

    /**
     * @return
     */
    public void registrarMedicion() {
        Medicion medicion = adapterMedicion.registrarMedicion();
        //mediciones.add(medicion);
        System.out.println("Medicion registrada");
    }

    /**
     * @param user 
     * @param password 
     * @return
     */
    public void ingresar(String user, String password) {
        adapterLogin.ingresar(user, password);
    }

    public Double getPesoIdeal(){ //como le paso este peso ideal
        return adapterMedicion.getPesoIdeal();
    }

    public Double getMasaIdeal(){ //como le paso este peso ideal
        return adapterMedicion.getMasaIdeal();
    }

    public Double getGrasaIdeal(){ //como le paso este peso ideal
        return adapterMedicion.getGrasaIdeal();
    }

    public void ObtenerPremio() {
        if (trofeos != null ) {
            for (TrofeoObservador trofeo: trofeos) {
                if (trofeo instanceof Dedicacion) {
                    System.out.println("estas en dedicacion");
                } else if (trofeo instanceof Creido) {
                    System.out.println("estas en creido");
                } else if (trofeo instanceof Constancia) {
                    System.out.println("estas en constancia");
                }
            }
        }
    }

    public TipoEstrategia getTipoEstrategia() {
        return tipoEstrategia;
    }

    public void cambiarObjetivo() {
        Rutina rutina = new Rutina();
        System.out.println("Nueva rutina creada para el nuevo objetivo: " + this.getTipoEstrategia());

    }

}