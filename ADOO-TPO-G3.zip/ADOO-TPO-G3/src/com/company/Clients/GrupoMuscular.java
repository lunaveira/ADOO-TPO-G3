package Clients;

/**
 * 
 */
public enum GrupoMuscular {
    PECHO,
    PIERNAS,
    ESPALDA,
    BRAZOS
}