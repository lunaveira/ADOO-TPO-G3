package Clients;

/**
 * 
 */
public enum TipoTrofeo {
    CREIDO,
    DEDICACION,
    CONSTANCIA
}