package Strategies;

import Clients.Socio;
import Clients.Medicion;

/**
 * 
 */
public class BajarPesoStrategy implements ObjetivoStrategy {

    private String nombreObjetivo;

    public BajarPesoStrategy() {
        this.nombreObjetivo = "Bajar de peso";
    }

    public String toString() {
        return this.nombreObjetivo;
    }


    @Override
    public boolean objCumplido(Socio socio) {
        socio.registrarMedicion();
        Medicion medicion = socio.getMediciones().get(2);
        if (socio.getPesoIdeal() == medicion.getPeso()){
            return true;
        }
        return false;
    }

}