package Strategies;

import Clients.Medicion;
import Clients.Socio;

/**
 * 
 */
public class TonificarStrategy implements ObjetivoStrategy {

    private String nombreObjetivo;

    public TonificarStrategy() {

        this.nombreObjetivo = "Tonificar";
    }

    public String toString() {
        return this.nombreObjetivo;
    }

    /**
     * @param socio
     * @return
     */
    public boolean objCumplido(Socio socio) {
        socio.registrarMedicion();
        Medicion medicion = socio.getMediciones().get(2);
        if (medicion.getMasa() == socio.getMasaIdeal() && medicion.getGrasa() == socio.getGrasaIdeal()){
            return true;
        }
        return false;

    }


}