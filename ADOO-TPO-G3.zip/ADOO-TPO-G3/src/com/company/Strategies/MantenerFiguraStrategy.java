package Strategies;

import Clients.Medicion;
import Clients.Objetivo;
import Clients.Socio;

/**
 * 
 */
public class MantenerFiguraStrategy implements ObjetivoStrategy {


    /**
     * Default constructor
     */
    public MantenerFiguraStrategy() {

    }

    private int valorConfigurable = 3;

    @Override
    public boolean objCumplido(Socio socio) {
        socio.registrarMedicion();
        Medicion medicion = socio.getMediciones().get(2);
        if (medicion.getPeso() == medicion.getPeso() - valorConfigurable || medicion.getPeso() == medicion.getPeso() + valorConfigurable ){
            return true;
        }
        return false;
    }
}