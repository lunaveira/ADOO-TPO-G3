package Strategies;


import Clients.Socio;

/**
 * 
 */
public interface ObjetivoStrategy {

    /**
     * @param socio
     * @return
     */
    boolean objCumplido(Socio socio);

}